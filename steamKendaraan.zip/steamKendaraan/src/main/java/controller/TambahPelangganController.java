package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.DatabaseConnection; // Pastikan kelas ini ada dan berfungsi

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TambahPelangganController {

    @FXML private TextField txtNoTelp;
    @FXML private TextField txtNamaPelanggan;
    @FXML private Button btnSimpan;
    @FXML private Button btnBatal;

    /**
     * Menutup jendela (Stage) saat tombol Batal diklik.
     */
    @FXML
    private void handleBatal() {
        // Ambil Stage dari tombol Batal
        Stage stage = (Stage) btnBatal.getScene().getWindow();
        stage.close();
    }

    /**
     * Menangani aksi Simpan untuk menambahkan data pelanggan baru ke database.
     */
    @FXML
    private void handleSimpanPelanggan() {
        String noTelp = txtNoTelp.getText().trim();
        String namaPelanggan = txtNamaPelanggan.getText().trim();

        // 1. Validasi Input
        if (noTelp.isEmpty() || namaPelanggan.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Validasi Gagal", "Semua bidang bertanda (*) harus diisi.");
            return;
        }
        
        // Opsional: Validasi format No. Telp (misalnya, hanya angka)
        if (!noTelp.matches("\\d+")) {
            showAlert(Alert.AlertType.WARNING, "Validasi Gagal", "Nomor Telepon hanya boleh mengandung angka.");
            return;
        }


        // 2. Simpan ke Database
        String sql = "INSERT INTO pelanggan (no_telp, nama_pelanggan) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, noTelp);
            ps.setString(2, namaPelanggan);
            
            ps.executeUpdate();
                
            // Tutup jendela setelah berhasil disimpan
            handleBatal(); 

        } catch (SQLException e) {
            // Error Code 1062 biasanya untuk Duplicate entry (ketika no_telp sudah ada)
            if (e.getErrorCode() == 1062) {
                showAlert(Alert.AlertType.ERROR, "Kesalahan Database", "Gagal menyimpan: Nomor Telepon ini (" + noTelp + ") sudah terdaftar sebagai pelanggan.");
            } else {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Kesalahan Database", "Gagal menambahkan pelanggan. Pesan: " + e.getMessage());
            }
        }
    }

    /**
     * Utility method untuk menampilkan dialog alert.
     */
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}