package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.DatabaseConnection;
import model.LayananData; 
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;

public class EditLayananController implements Initializable {

    @FXML private TextField txtNamaLayanan;
    @FXML private TextField txtHarga;
    @FXML private ComboBox<String> cbJenisKendaraan;
    @FXML private Button btnBatal;
    @FXML private Button btnUpdate;

    private LayananData layananToEdit;
    private KelolaLayananController parentController; // Reference ke controller utama

    private final ObservableList<String> jenisKendaraanList = FXCollections.observableArrayList("Mobil", "Motor");

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cbJenisKendaraan.setItems(jenisKendaraanList);
        btnBatal.setOnAction(e -> closeWindow());
    }

    public void initData(LayananData layanan, KelolaLayananController parent) {
        this.layananToEdit = layanan;
        this.parentController = parent;

        if (layananToEdit == null) {
            showAlert("Error Data", "Data layanan yang akan diedit tidak ditemukan.", Alert.AlertType.ERROR);
            closeWindow();
            return;
        }

        // Isi field form dengan data yang ada
        txtNamaLayanan.setText(layanan.getNamaLayanan());
        txtHarga.setText(String.valueOf(layanan.getHarga()));
        
        // Konversi ID kendaraan (1, 2) ke teks ("Mobil", "Motor")
        int idKendaraan = layanan.getJenisKendaraanId();
        if (idKendaraan == 1) {
            cbJenisKendaraan.getSelectionModel().select("Mobil");
        } else if (idKendaraan == 2) {
            cbJenisKendaraan.getSelectionModel().select("Motor");
        } else {
            cbJenisKendaraan.getSelectionModel().clearSelection();
        }
    }

    @FXML
    private void handleUpdateLayanan() {
        String namaLayanan = txtNamaLayanan.getText().trim();
        String hargaText = txtHarga.getText().trim();
        String jenisKendaraan = cbJenisKendaraan.getSelectionModel().getSelectedItem();
        
        if (layananToEdit == null) {
             showAlert("Error Internal", "Data layanan hilang.", Alert.AlertType.ERROR);
             return;
        }

        // --- 1. Validasi Input Wajib ---
        if (namaLayanan.isEmpty() || hargaText.isEmpty() || jenisKendaraan == null) {
            showAlert("Validasi", "Semua field wajib diisi.", Alert.AlertType.WARNING);
            return;
        }

        // --- 2. Validasi Format Harga ---
        double harga;
        try {
            harga = Double.parseDouble(hargaText);
            if (harga <= 0) {
                showAlert("Validasi Harga", "Harga harus lebih dari nol.", Alert.AlertType.WARNING);
                return;
            }
        } catch (NumberFormatException e) {
            showAlert("Validasi Harga", "Format harga tidak valid. Masukkan hanya angka.", Alert.AlertType.WARNING);
            return;
        }

        // --- 3. Konversi Jenis Kendaraan (Teks) ke ID (Integer) ---
        int idKendaraan = getJenisKendaraanId(jenisKendaraan);
        
        if (idKendaraan == 0) {
            showAlert("Validasi", "Jenis kendaraan tidak valid.", Alert.AlertType.WARNING);
            return;
        }

        // --- 4. Eksekusi Query Update ---
        String sql = "UPDATE layanan SET nama_layanan = ?, harga = ?, id_kendaraan = ? WHERE id_layanan = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, namaLayanan);
            ps.setDouble(2, harga);
            ps.setInt(3, idKendaraan);
            ps.setInt(4, layananToEdit.getIdLayanan()); 

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                // Sukses: Panggil loadData di parent controller untuk refresh
                if (parentController != null) {
                    parentController.loadData();
                }
                
                closeWindow();
            } else {
                showAlert("Update Gagal", "Gagal memperbarui data layanan. Mungkin tidak ada perubahan data.", Alert.AlertType.ERROR);
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Database Error", "Terjadi kesalahan saat update layanan: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleBatal() {
        closeWindow();
    }
    
    // --- UTILITY METHODS ---

    private void closeWindow() {
        Stage stage = (Stage) btnBatal.getScene().getWindow();
        stage.close();
    }

    private void showAlert(String title, String msg, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private int getJenisKendaraanId(String jenisKendaraan) {
        if ("Mobil".equals(jenisKendaraan)) {
            return 1;
        } else if ("Motor".equals(jenisKendaraan)) {
            return 2;
        }
        return 0; // Invalid
    }
}